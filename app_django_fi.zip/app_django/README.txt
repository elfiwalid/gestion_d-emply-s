######
superuser = administrateur
username = walid
passwd = walidwalid1234567890@

## pour créer un nouveau user 
https://127.0.0.1:8000/admin
---entrer sur user aprés tu peux creer un nouveau user
---pour ajouter un membres c'est obligatoire de mettre une photo de profile
