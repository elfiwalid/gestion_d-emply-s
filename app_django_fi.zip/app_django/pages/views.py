from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm , AuthenticationForm
from django.contrib.auth import authenticate , login , logout
from .forms import CustomUserCreationForm
from django.contrib.auth import login as auth_login
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from .forms import AddEmployeeForm
from .models import Member
from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from django.http import HttpResponse
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.signals import user_logged_in, user_logged_out
from .models import Presence
from datetime import datetime
from django.views.generic import ListView
from django.contrib.auth import logout
from django.views import View
from .models import Email
from django.core.mail import send_mail, BadHeaderError
from .models import paie as PaieModel
from .models import contrat
from django.utils import timezone
from django.db.models import Sum
from django.db.models import Count
from django.contrib.auth.models import User
from .models import Offre
from .forms import OffreForm
from .forms import CandidatureForm
from .models import Candidature
from random import randint
from .models import Horaire
from .forms import HoraireForm







def index(request):
    return render(request, 'index.html')
def about(request):
    return render(request, 'about.html')
def project(request):
    return render(request, 'project.html')
def blog(request):
    return render(request, 'blog.html')
def service(request):
    return render(request, 'service.html')
def team(request):
    return render(request, 'team.html')
def contact(request):
    return render(request, 'contact.html')



def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            if user.is_superuser:
                return redirect('administration')
            else:
                return redirect('employe_home')
    return render(request, 'login.html')

@login_required
def administration(request):
    if request.user.is_superuser:
        return render(request, 'administration.html')
    else:
        return redirect('employe_home')

@login_required
def employe_home(request):
    return render(request, 'employe_home.html')





''' functions de recherche'''

def departement(request):
    if request.method == 'POST':
        q = request.POST.get('q')
        members = Member.objects.filter(matricule__icontains=q)
    else:
        members = Member.objects.all()
    context = {
        'members': members
    }
    return render(request, 'departement.html', context)

''' functions d'ajouter l'employe'''

def add_employee(request):
    if request.method == 'POST':
        form = AddEmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('administration')
    else:
        form = AddEmployeeForm()

    return render(request, 'add_employe.html', {'form': form})


''' functions d'afficher les employes'''
def departement(request):
    employes = Member.objects.all()  # Récupérer tous les employés
    print(employes)  # Vérifier les données dans la console Django
    return render(request, 'departement.html', {'employes': employes})




def dashboard(request):
    members = Member.objects.all()
    return render(request, 'dashboard.html', {'members': members})


def profile(request):
    members = Member.objects.all()
    return render(request,'profile.html' , {'members': members})


def supprimer_employe(request, matricule):
    member = Member.objects.get(matricule=matricule)
    member.delete()
    return redirect('administration')

def modifier_employe(request, matricule):
    employee = Member.objects.get(matricule=matricule)
    if request.method == 'POST':
        form = AddEmployeeForm(request.POST, instance=employee)
        if form.is_valid():
            form.save()
            return redirect('administration')
    else:
        form = AddEmployeeForm(instance=employee)

    return render(request, 'modifier_employe.html', {'form': form, 'employee': employee})



def info_employe(request, matricule):
    member = Member.objects.get(matricule=matricule)
    context = {
        'member': member

    }
    return render(request, 'info_employe.html', context)



@receiver(user_logged_in)
def set_start_time(sender, request, user, **kwargs):
    # Utilisation de filter() au lieu de get()
    presences = Presence.objects.filter(user=user, date=datetime.today().date())
    
    if presences.exists():
        # Gérer le cas où il y a déjà des présences
        presence = presences.first()  # Prendre le premier s'il y en a plusieurs
    else:
        # Créer un nouveau si aucun n'existe
        presence = Presence(user=user, date=datetime.today().date(), date_debut=datetime.now())
    
    presence.save()



@receiver(user_logged_out)
def set_end_time(sender, request, user, **kwargs):
    # Récupérer l'enregistrement de présence de cet utilisateur pour aujourd'hui
    presence = Presence.objects.filter(user=user, date=datetime.today().date()).first()
    if presence and not presence.date_fin:
        # Si l'enregistrement existe et qu'il n'a pas d'heure de fin, la définir
        presence.date_fin = datetime.now()
    presence.save()


class PresenceListView(ListView):
    model = Presence
    template_name = 'presence_list.html'
    context_object_name = 'presences'
    ordering = ['-date']

def presence_list(request):
    presences = Presence.objects.all()  # Récupérer toutes les présences
    return render(request, 'presence_list.html', {'presences': presences})

class CustomLogoutView(View):
    def get(self, request):
        logout(request)  # Déconnecte l'utilisateur
        return redirect('/')

def rapport(request):
    members = Member.objects.all()
    return render(request, 'rapport.html', {'members': members})

def rapport(request):
    if request.method == 'POST':
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        sender_email = request.POST.get('sender')
        admin_email = 'admin@gmail.com'  # Remplacez par l'adresse e-mail de l'administrateur

        if subject and message and sender_email:
            try:
                send_mail(subject, message, sender_email, [admin_email])
            except BadHeaderError:
                return HttpResponse('Invalid header found.')
            except Exception as e:
                # Gérer d'autres exceptions d'envoi d'e-mails
                return HttpResponse(f'An error occurred: {str(e)}')
            else:
                return HttpResponse('Email sent successfully!')
        else:
            return HttpResponse('Please fill all the fields!')
    else:
        return render(request, 'rapport.html')




@login_required
def profile(request):
    member = request.user.member
    return render(request, 'profile.html', {'member': member})



@login_required
def paie(request):
    paies = PaieModel.objects.filter(user=request.user)
    contrats = contrat.objects.filter(user=request.user)
    return render(request, 'paie.html', {'paies': paies ,'contrats':contrats} )


def creer_offre(request):
    if request.method == 'POST':
        form = OffreForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('administration')
    else:
        form = OffreForm()
    return render(request, 'creer_offre.html', {'form': form})


def postuler(request, offre_id=None):
    if request.method == 'POST':
        form = CandidatureForm(request.POST, request.FILES)
        if form.is_valid():
            candidature = form.save(commit=False)
            if offre_id:
                offre = Offre.objects.get(id=offre_id)
                candidature.offre = offre
            candidature.save()
            return redirect('index')
    else:
        form = CandidatureForm()
    return render(request, 'postuler.html', {'form': form})

def liste_candidatures(request):
    candidatures = Candidature.objects.prefetch_related('offre').all()
    return render(request, 'liste_candidatures.html', {'candidatures': candidatures})


def offre_postuler(request):
    offres = Offre.objects.all()
    return render(request, 'offre_postuler.html', {'offres': offres})



def statistiques_view(request):
    if request.user.is_authenticated:
        # Calcul des statistiques
        nombre_employes = Member.objects.count()
        nombre_offres = Offre.objects.count()
        candidatures = Candidature.objects.count()
        
        # Calcul du nombre de connexions par employé et multiplication par 10
        employees_stats = []
        for user in User.objects.all():
            connexions = Presence.objects.filter(user=user).count() * 2
            employees_stats.append({'nom': user.username, 'connexions': connexions})
        
        # Passer les statistiques au template
        context = {
            'nombre_employes': nombre_employes,
            'nombre_offres': nombre_offres,
            'candidatures' : candidatures,
            'employees_stats': employees_stats
        }
        return render(request, 'performance_review.html', context)
    else:
        # Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
        return redirect('login')

def generate_employee_colors(employees):
    colors = ['#ff5733', '#33ff57', '#5733ff', '#ff33b8', '#b8ff33', '#33b8ff']  # Palette de couleurs
    for employee in employees:
        employee.color = colors[randint(0, len(colors) - 1)]  # Attribution aléatoire d'une couleur à chaque employé


@login_required
def creer_horaire(request):
    if request.method == 'POST':
        form = HoraireForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Horaire créé avec succès.')
            return redirect('creer_horaire')
    else:
        form = HoraireForm()
    return render(request, 'creer_horaire.html', {'form': form})


@login_required
def liste_horaires(request):
    horaires = Horaire.objects.filter(user=request.user)
    return render(request, 'liste_horaires.html', {'horaires': horaires})
