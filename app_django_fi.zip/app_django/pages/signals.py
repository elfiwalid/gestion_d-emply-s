from django.contrib.auth.signals import user_logged_in, user_logged_out
from django.dispatch import receiver
from datetime import datetime
from .models import Presence

@receiver(user_logged_in)
def handle_user_logged_in(sender, request, user, **kwargs):
    # Récupérer la dernière présence pour cet utilisateur et cette date
    presence = Presence.objects.filter(user=user, date=datetime.today().date()).order_by('-date_debut').first()
    
    if presence and not presence.date_fin:
        # Si une présence existe pour cet utilisateur et cette date, et que la date de fin n'est pas définie, la mettre à jour
        presence.date_fin = datetime.now()
        presence.save()

    # Créer une nouvelle présence pour cet utilisateur et cette date avec la date de début actuelle
    new_presence = Presence(user=user, date=datetime.today().date(), date_debut=datetime.now())
    new_presence.save()



@receiver(user_logged_out)
def handle_user_logged_out(sender, request, user, **kwargs):
    presence = Presence.objects.filter(user=user, date=datetime.today().date()).order_by('-date_debut').first()
    if presence and not presence.date_fin:
        presence.date_fin = datetime.now()  # Heure de fin lors de la déconnexion
        presence.save()