from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
from .models import Member
from django import forms
from .models import Offre, Candidature
from .models import Horaire




class CustomUserCreationForm(UserCreationForm):
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'password1', 'password2')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Supprimer les messages d'erreur indésirables
        self.fields['password1'].help_text = None
        self.fields['password2'].help_text = None

    def clean_password2(self):
        password1 = self.cleaned_data.get('password1')
        password2 = self.cleaned_data.get('password2')
        if password1 and password2 and password1 != password2:
            raise ValidationError(_('Les mots de passe ne correspondent pas.'))
        return password2


class AddEmployeeForm(forms.ModelForm):
    class Meta:
        model = Member
        fields = ['matricule', 'nom', 'prenom', 'departement' , 'genre' ,'region','salaire','type_contrat','fin_contrat' ]



class OffreForm(forms.ModelForm):
    class Meta:
        model = Offre
        fields = ['titre', 'description', 'experience', 'date_expiration']
        widgets = {
            'titre': forms.TextInput(attrs={
                'class': 'form-control', 
                'placeholder': 'Titre de l\'offre'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control', 
                'placeholder': 'Description de l\'offre',
                'rows': 4
            }),
            'experience': forms.NumberInput(attrs={
                'class': 'form-control', 
                'placeholder': 'Années d\'expérience'
            }),
            'date_expiration': forms.DateInput(attrs={
                'class': 'form-control', 
                'placeholder': 'Date d\'expiration (AAAA-MM-JJ)',
                'type': 'date'
            }),
        }


class CandidatureForm(forms.ModelForm):
    class Meta:
        model = Candidature
        fields = ['nom', 'email', 'cv']
        widgets = {
            'nom': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'cv': forms.FileInput(attrs={'class': 'form-control'}),
        }



class HoraireForm(forms.ModelForm):
    class Meta:
        model = Horaire
        fields = ['user', 'date', 'heure_debut', 'heure_fin']