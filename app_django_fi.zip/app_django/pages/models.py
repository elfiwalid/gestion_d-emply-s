from django.db import models
from django.urls import reverse
from django.contrib.auth.models import User
from datetime import datetime, timedelta
from django.views.generic import ListView
from django.utils import timezone
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager


# Create your models here.
class Member(models.Model):
#    user = models.ForeignKey(User, on_delete=models.CASCADE , null=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True )
    idd = models.AutoField(primary_key=True)
    matricule = models.CharField(max_length=100)
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    departement = models.CharField(max_length=100)
    genre = models.CharField(max_length=100,null=True)
    region = models.CharField(max_length=100,null=True)
    salaire = models.CharField(max_length=100,null=True)
    type_contrat = models.CharField(max_length=100,null=True)
    fin_contrat = models.CharField(max_length=100,null=True)
    photo = models.ImageField(upload_to='employee_photos', null=True)

    
    def get_absolute_url(self):
        return reverse('info_employe', kwargs={'matricule': self.matricule})
    


class Presence(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)  # Date de la présence
    date_debut = models.DateTimeField(null=True, blank=True)  # Heure de début de travail
    date_fin = models.DateTimeField(null=True, blank=True)  # Heure de fin de travail


    def __str__(self):
        return f"{self.user.username} - {self.date}"

class PresenceListView(ListView):
    model = Presence
    template_name = 'presence_list.html'
    context_object_name = 'presences'
    ordering = ['-date']


class Utilisateur(models.Model):
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=100)

#class info(models.Model):
 #   nom = models.CharField(max_length=100)
#    salaire = models.CharField(max_length=100)
 #   type_contrat = models.CharField(max_length=100)
 #   fin_contrat = models.CharField(max_length=100)

class Email(models.Model):
    sender = models.EmailField()
    recipient = models.EmailField()
    subject = models.CharField(max_length=255)
    message = models.TextField()



#class InfoEmploye(models.Model):
#    name = models.CharField(max_length=100)
#    gender = models.CharField(max_length=100)
#    Salary = models.CharField(max_length=100)
 #   type_contrats = models.CharField(max_length=100)
 #   end_contrat = models.CharField(max_length=100)
    

class paie(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField()
    salaire = models.DecimalField(max_digits=10, decimal_places=2)
    file = models.FileField(upload_to='paie/')


class contrat(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    type_contrat = models.CharField(max_length=100)
    file = models.FileField(upload_to='contrat/')


class Offre(models.Model):
    titre = models.CharField(max_length=255)
    description = models.TextField()
    date_publication = models.DateTimeField(auto_now_add=True)
    experience = models.CharField(max_length=255, null=True)
    date_expiration = models.DateTimeField()

class Candidature(models.Model):
    offre = models.ForeignKey(Offre, related_name='candidatures', on_delete=models.CASCADE, blank=True, null=True)
    nom = models.CharField(max_length=255)
    email = models.EmailField()
    cv = models.FileField(upload_to='cvs/')
    date_postulation = models.DateTimeField(auto_now_add=True)


class Horaire(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField()
    heure_debut = models.TimeField()
    heure_fin = models.TimeField()

    def __str__(self):
        return f"{self.date} ({self.heure_debut} - {self.heure_fin}"