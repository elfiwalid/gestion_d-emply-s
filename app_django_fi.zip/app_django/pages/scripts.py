from django.contrib.auth.models import User
from .models import CustomUser


# Récupérer l'utilisateur administrateur
admin_user = User.objects.get(username='walid')

# Associer l'adresse e-mail "walid@gmail.com" à l'utilisateur administrateur
admin_user.email = 'walid11elfilali@gmail.com'
admin_user.save()



# Récupérer l'utilisateur administrateur
admin_user = CustomUser.objects.filter(is_superuser=True).first()

if admin_user:
    # Associer l'adresse e-mail "walid@gmail.com" à l'utilisateur administrateur
    admin_user.email = 'walid11elfilali@gmail.com'
    admin_user.save()
else:
    # Gérer le cas où aucun utilisateur administrateur n'est trouvé
    print("Aucun utilisateur administrateur trouvé.")