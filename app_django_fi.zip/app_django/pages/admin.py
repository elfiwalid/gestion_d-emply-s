from django.contrib import admin
from .models import Member
from .models import Email
from .models import paie
from .models import contrat
from .models import Horaire

admin.site.register(Member)
admin.site.register(Email)
admin.site.register(paie)
admin.site.register(contrat)
admin.site.register(Horaire)
