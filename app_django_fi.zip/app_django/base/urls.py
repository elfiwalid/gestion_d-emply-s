"""base URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from pages import views
from django.conf.urls.static import static
from django.conf import settings



urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='home'),
    path('login/', views.login, name='login'),
    path('administration/', views.administration, name='administration'),
    path('employe_home/', views.employe_home, name='employe_home'),
    path('supprimer_employe/', views.supprimer_employe, name='supprimer_employe'),
    path('departement/', views.departement, name='departement'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('departement/<int:departement_id>/', views.departement, name='departement'),
    path('add_employe/', views.add_employee, name='add_employe'),
    path('supprimer_employe/<str:matricule>/', views.supprimer_employe, name='supprimer_employe'),
    path('modifier_employe/<str:matricule>/', views.modifier_employe, name='modifier_employe'),
    path('info_employe/<str:matricule>/', views.info_employe, name='info_employe'),
    path('presence_list/', views.PresenceListView.as_view(), name='presence_list'),
    path('logout/', views.CustomLogoutView.as_view(), name='custom_logout'),
    path('rapport/', views.rapport, name='rapport'),
    path('profile/', views.profile , name='profile'),
    path('paie/', views.paie , name='paie'),
    path('about/', views.about , name='about'),
    path('blog/', views.blog , name='blog'),
    path('service/', views.service , name='service'),
    path('team/', views.team , name='team'),
    path('contact/', views.contact , name='contact'),
    path('project/', views.project , name='project'),
    path('index/', views.index , name='index'),
    path('creer_offre/', views.creer_offre , name='creer_offre'),
    path('offre_postuler/', views.offre_postuler , name='offre_postuler'),
    path('postuler/', views.postuler , name='postuler'),
    path('liste_candidatures/', views.liste_candidatures , name='liste_candidatures'),
    path('performance_review/', views.statistiques_view , name='statistiques_view'),
    path('creer_horaire/', views.creer_horaire, name='creer_horaire'),
    path('liste_horaires/', views.liste_horaires, name='liste_horaires'),



   ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)